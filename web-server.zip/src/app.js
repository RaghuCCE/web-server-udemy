const path = require('path');
const express = require('express');

const app = express();

const sPublicDirPath = path.join(__dirname, './../public');

app.use(express.static(sPublicDirPath));

app.get('/weather', (req, res) => {
    res.send('Weather route');
})

app.listen(3000, () => {
    console.log('Server is running on port 3000');
})